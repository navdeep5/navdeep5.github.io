Window_Base.prototype.standardFontSize = function () {
    return 24;
};
